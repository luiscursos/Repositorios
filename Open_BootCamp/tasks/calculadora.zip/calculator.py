import pprint
# class calculator():

#     print("Menu:")
#     print("""
#     1 - Addition
#     2 - Subtraction
#     3 - Multiplication
#     4 - Division
#     0 - Exit
#     """)

# option = int(input("choice option, 0 to 4: "))    

# if 0<=option<=4:
#     num1 = int(input("Enter the first number: "))
#     num2 = int(input("Enter a second number: "))
#     if option == 1:    
#         def addition():
#             return num1 + num2
#     elif option == 2:       
#         def subtraction():
#             return num1 - num2
#     elif option == 3:    
#         def multiplication():
#             return num1 * num2
#     elif option == 4:        
#         def division (num1, num2):
#             return num1 // num2
# else:
#     print("prueba una opcion del 0 al 4")

class calculadora:

    def addition(num1,num2):
        return num1 + num2
    
    def subtraction(num1,num2):
            return num1 - num2

    def multiplication(num1,num2):
            return num1 * num2
    
    def division(num1,num2):
            return num1 // num2



