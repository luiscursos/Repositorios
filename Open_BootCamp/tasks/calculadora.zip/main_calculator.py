from calculator import calculadora

add = calculadora.addition(20,200)
sub = calculadora.subtraction(20,200)
mult = calculadora.multiplication(20,200)
div = calculadora.division(20,200)

print(add)
print(sub)
print(mult)
print(div)


